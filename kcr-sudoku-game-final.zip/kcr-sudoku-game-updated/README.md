# KCR Sudoku - Masaüstü Uygulaması

Hoş geldiniz! **KCR Sudoku** oyununu PC'nizde oynamaya hazırsınız.

## Nasıl Başlayacaksınız?

### Windows Kullanıcıları:

**Seçenek 1: Python ile (Önerilen)**
1. `start.bat` dosyasına çift tıklayın
2. Siyah bir pencere açılacak
3. Tarayıcınız otomatik olarak oyunu açacak
4. Oyunu oynamaya başlayabilirsiniz!

**Seçenek 2: Node.js ile**
1. `start-nodejs.bat` dosyasına çift tıklayın
2. Tarayıcınız otomatik olarak açılacak

### Mac/Linux Kullanıcıları:

1. Terminal açın
2. Bu klasöre gidin
3. Şu komutu yazın:
   ```bash
   ./start.sh
   ```
4. Tarayıcıda `http://localhost:8000` adresine gidin

## Sistem Gereksinimleri

- **Windows, Mac veya Linux**
- **Python 3** (veya Node.js)
- **Modern bir web tarayıcısı** (Chrome, Firefox, Edge, Safari)

## Sorun Giderme

**"Python bulunamadı" hatası alıyorsanız:**
- Python 3'ü https://www.python.org/downloads/ adresinden indirin
- Kurulum sırasında "Add Python to PATH" seçeneğini işaretleyin

**Port 8000 zaten kullanımda ise:**
- `start.bat` dosyasını Not Defteri ile açın
- `8000` yerine `8001` yazın
- Tarayıcıda `http://localhost:8001` gidin

## Oyun Özellikleri

✨ **Zen Minimalist Tasarım** - Sakinleştirici atmosfer
🎮 **4 Zorluk Seviyesi** - Kolay, Orta, Zor, Uzman
💡 **İpucu Sistemi** - Oyun başına 3 ipucu
⌨️ **Klavye Desteği** - Sayıları yazarak veya panelden seçerek girin
🎯 **Hata Kontrolü** - Yanlış hamleleri anında gösterir

## Kontroller

- **Sayı Girmek:** Paneldeki butonlara tıklayın veya klavyede 1-9 tuşlarına basın
- **Silmek:** Silgi butonuna tıklayın veya Backspace tuşuna basın
- **Hücre Seçmek:** Fare ile tıklayın veya ok tuşlarını kullanın
- **İpucu Almak:** Ampul butonuna tıklayın

## Yapımcı

Made with **Eyüp KAÇAR**

---

Oyunu beğendiyseniz, arkadaşlarınızla paylaşın! 🎉
