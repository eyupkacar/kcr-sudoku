@echo off
cd /d "%~dp0"
npx http-server -p 8000 -o http://localhost:8000
pause
